<?php
  $conexao = mysqli_connect("localhost",'root','',"bd_webbasico");	      
?>